# ATL After Dark

Atlanta dining and nightlife map prototype. Deploy as a static site to Vercel.

## Current capabilities
154 venue entries, category and neighborhood search, favorites stored in this browser, and event leads.

## Limitations
Pins are approximate neighborhood points, **not verified restaurant coordinates**. Event leads are **not a live or continuously updated calendar**. Favorites are not synced between devices. External Leaflet and CARTO tile assets require an internet connection.

## Deploy
Upload `index.html` and `vercel.json` to the root of the GitHub repository (do not upload the ZIP itself). Then import the GitHub repository at https://vercel.com/new and deploy with Framework Preset `Other`.

## Next phase
Supabase Auth, row-level secured favorites, verified geocoding, and sourced events ingestion.
